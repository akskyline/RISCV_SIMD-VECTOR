# Full RV32I core + retire trace + reference model + vector coprocessor

## What changed (delete / replace these in your ModelSim project)
DELETE the old files: `rv32i_core_modules.sv`, `core_missing_modules.sv`, `sgle_cyc_processor_tb.sv`, the old
`riscv_soc_top.sv`, and any old file that defines `data_mem` / `imm_data` / `memtoreg_mux_3to1`.
Then start from an empty library (`vdel -lib work -all` + `vlib work`) so no stale module is left behind.

| file | what it is |
|---|---|
| `rtl/rv32i_types.svh` | constants + the retire-trace record (`rvfi_t`) |
| `rtl/rv32i_core_modules.sv` | **the full RV32I core** (`rv32i_core` = CPU without memories) and all its sub-modules |
| `rtl/rv32i_memories.sv` | `ins_mem` (64 KB, `+HEX=file`), `data_mem` (64 KB, byte enables, `+DHEX=file`) |
| `rtl/sgle_cyc_processor.sv` | your original top name: core + ins_mem + data_mem |
| `rtl/riscv_soc_top.sv` | core + memories + address decode + `vec_coproc` |
| `rtl/vec_*.sv, vec_defs.svh` | vector coprocessor (unchanged) |
| `tb/rv32i_iss.sv` | independent reference model (instruction-set simulator) |
| `tb/rv32i_tb.sv` | lockstep testbench: every retired instruction DUT vs model |
| `tb/riscv_soc_tb.sv`, `tb/vec_coproc_tb.sv` | SoC integration test, coprocessor unit test |
| `tests/*.S`, `hex/*.hex` | directed + trap programs (source + ready-made hex) |
| `soc/soc_prog.S`, `soc/ins_little_endian.hex` | program for the SoC test |
| `scripts/` | assembler, generators, regression, mutation test, ModelSim `.do` |

## Run in ModelSim
```tcl
vdel -lib work -all
vlib work
vlog -sv +incdir+rtl rtl/*.sv tb/*.sv
vsim -voptargs=+acc work.rv32i_tb +HEX=hex/t_ctrl.hex      ;# add wave -r /*   then   run -all
vsim -c work.riscv_soc_tb +HEX=soc/ins_little_endian.hex -do "run -all; quit"
do scripts/run_modelsim.do                                   ;# runs everything
```
Testbench options (all `+plusargs`): `+HEX=` program, `+DHEX=` data init, `+QUIET`, `+STOP_PC=<hex>` (for
programs ending in a `jal x0,0` loop), `+EXPECT_CAUSE=<n>`, `+MAXCYC=<n>`, `+COV`, `+VCD`.

## Policies (no CSRs in base RV32I, so the core halts on a trap)
* trap = illegal instruction, ECALL, EBREAK, misaligned load / store, misaligned jump / taken-branch target.
  The instruction retires ONCE with `trap=1` and no side effect, the PC freezes, `halted` goes high until reset.
  Cause numbers = RISC-V `mcause` (0 fetch misaligned, 2 illegal, 3 ebreak, 4 load, 6 store, 11 ecall).
* ECALL is therefore the normal "end of program".  FENCE = no-op.  FENCE.I, CSR instructions, `mul`, compressed
  encodings are illegal (base RV32I only).
* Memories are separate (Harvard): instruction memory and data memory both start at address 0.
* SoC map: SRAM 0x0000_0000-0xFFFF, coprocessor 0x4000_0000 (2 KB, word access only), everything else unmapped
  (reads 0, writes ignored).

## Retire trace (`rvfi` port, RVFI-style field names, see `rvfi_t`)
One record per retired instruction, valid in the cycle it executes: sample on the rising clock edge.
`mem_addr` is word aligned; `mem_rmask/mem_wmask` say which bytes were read / written. Extra field `cause`.

## Verification done
* lockstep vs the reference model on every instruction (all trace fields) + final registers, PC, data memory
* every directed / trap program, over 200 random programs, all also cross-checked against the Unicorn (QEMU) emulator
* assembler cross-checked byte-for-byte against GNU `as` (`scripts/check_asm_vs_gnu.py`)
* 33 injected RTL bugs (mutation test, `scripts/mutation_test.py`) - all detected
* 40 / 40 RV32I instructions executed; all 6 trap causes; misaligned-not-taken branch does not trap
