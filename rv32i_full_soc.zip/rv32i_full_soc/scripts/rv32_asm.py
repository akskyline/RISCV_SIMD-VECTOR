#!/usr/bin/env python3
"""
rv32_asm.py - small assembler for the complete RV32I base ISA (40 instructions).

    python3 rv32_asm.py prog.S ins_little_endian.hex      # writes hex, prints listing

Output = what ins_mem's $readmemh expects: ONE BYTE PER LINE, little-endian.

Supported
  R : add sub sll slt sltu xor srl sra or and
  I : addi slti sltiu xori ori andi  slli srli srai   jalr
  L : lb lh lw lbu lhu               (rd, imm(rs1))
  S : sb sh sw                       (rs2, imm(rs1))
  B : beq bne blt bge bltu bgeu      (rs1, rs2, label | byte-offset)
  U : lui auipc                      (rd, imm20)
  J : jal                            (rd, label)  |  jal label
  - : fence ecall ebreak
  pseudo: nop li mv not neg seqz snez sltz sgtz beqz bnez blez bgez bltz bgtz
          bgt ble bgtu bleu j jr ret
  directive: .word <n>[, <n> ...]     (raw 32-bit words, e.g. to inject an illegal instruction)
Registers: x0..x31 and the ABI names (zero ra sp gp tp t0-t6 s0/fp s1-s11 a0-a7).
Comments start with '#'. Labels end with ':' and may share a line with an instruction.
"""
import re
import sys

ABI = {"zero": 0, "ra": 1, "sp": 2, "gp": 3, "tp": 4, "t0": 5, "t1": 6, "t2": 7, "s0": 8, "fp": 8, "s1": 9,
       "a0": 10, "a1": 11, "a2": 12, "a3": 13, "a4": 14, "a5": 15, "a6": 16, "a7": 17,
       "s2": 18, "s3": 19, "s4": 20, "s5": 21, "s6": 22, "s7": 23, "s8": 24, "s9": 25, "s10": 26, "s11": 27,
       "t3": 28, "t4": 29, "t5": 30, "t6": 31}

OP_LUI, OP_AUIPC, OP_JAL, OP_JALR = 0x37, 0x17, 0x6F, 0x67
OP_BR, OP_LD, OP_ST, OP_IMM, OP_REG, OP_FENCE, OP_SYS = 0x63, 0x03, 0x23, 0x13, 0x33, 0x0F, 0x73

R_OPS = {"add": (0, 0x00), "sub": (0, 0x20), "sll": (1, 0), "slt": (2, 0), "sltu": (3, 0),
         "xor": (4, 0), "srl": (5, 0), "sra": (5, 0x20), "or": (6, 0), "and": (7, 0)}
I_OPS = {"addi": 0, "slti": 2, "sltiu": 3, "xori": 4, "ori": 6, "andi": 7}
SH_OPS = {"slli": (1, 0x00), "srli": (5, 0x00), "srai": (5, 0x20)}
LD_OPS = {"lb": 0, "lh": 1, "lw": 2, "lbu": 4, "lhu": 5}
ST_OPS = {"sb": 0, "sh": 1, "sw": 2}
BR_OPS = {"beq": 0, "bne": 1, "blt": 4, "bge": 5, "bltu": 6, "bgeu": 7}


class AsmError(Exception):
    pass


def reg(tok):
    t = tok.strip().lower()
    if t in ABI:
        return ABI[t]
    m = re.fullmatch(r"x(\d+)", t)
    if m and 0 <= int(m.group(1)) < 32:
        return int(m.group(1))
    raise AsmError(f"bad register '{tok}'")


def num(tok):
    t = tok.strip()
    try:
        return int(t, 0)
    except ValueError:
        raise AsmError(f"bad number '{tok}'")


def chk(v, lo, hi, what):
    if not lo <= v <= hi:
        raise AsmError(f"{what} {v} out of range [{lo}, {hi}]")
    return v


def e_r(f3, f7, rd, rs1, rs2):
    return (f7 << 25) | (rs2 << 20) | (rs1 << 15) | (f3 << 12) | (rd << 7) | OP_REG


def e_i(op, f3, rd, rs1, imm):
    chk(imm, -2048, 2047, "12-bit immediate")
    return ((imm & 0xFFF) << 20) | (rs1 << 15) | (f3 << 12) | (rd << 7) | op


def e_shift(f3, f7, rd, rs1, sh):
    chk(sh, 0, 31, "shift amount")
    return (f7 << 25) | (sh << 20) | (rs1 << 15) | (f3 << 12) | (rd << 7) | OP_IMM


def e_s(f3, rs2, rs1, imm):
    chk(imm, -2048, 2047, "12-bit immediate")
    imm &= 0xFFF
    return ((imm >> 5) << 25) | (rs2 << 20) | (rs1 << 15) | (f3 << 12) | ((imm & 0x1F) << 7) | OP_ST


def e_b(f3, rs1, rs2, off):
    if off % 2:
        raise AsmError(f"branch offset {off} is odd")
    chk(off, -4096, 4094, "branch offset")
    o = off & 0x1FFF
    return (((o >> 12) & 1) << 31) | (((o >> 5) & 0x3F) << 25) | (rs2 << 20) | (rs1 << 15) | \
           (f3 << 12) | (((o >> 1) & 0xF) << 8) | (((o >> 11) & 1) << 7) | OP_BR


def e_u(op, rd, imm20):
    chk(imm20, -(1 << 19), (1 << 20) - 1, "20-bit immediate")
    return ((imm20 & 0xFFFFF) << 12) | (rd << 7) | op


def e_j(rd, off):
    if off % 2:
        raise AsmError(f"jal offset {off} is odd")
    chk(off, -(1 << 20), (1 << 20) - 2, "jal offset")
    o = off & 0x1FFFFF
    return (((o >> 20) & 1) << 31) | (((o >> 1) & 0x3FF) << 21) | (((o >> 11) & 1) << 20) | \
           (((o >> 12) & 0xFF) << 12) | (rd << 7) | OP_JAL


def li_parts(val):
    """Return [(kind, imm)] : ('addi', v) or ('lui', hi[, then 'addi', lo])."""
    v = val & 0xFFFFFFFF
    sv = v - (1 << 32) if v & 0x80000000 else v
    if -2048 <= sv <= 2047:
        return [("addi", sv)]
    hi = ((v + 0x800) >> 12) & 0xFFFFF
    lo = v - (hi << 12)
    lo = ((lo + (1 << 31)) & 0xFFFFFFFF) - (1 << 31)          # signed 32
    lo = lo if -2048 <= lo <= 2047 else (lo & 0xFFF) - (0x1000 if (lo & 0x800) else 0)
    parts = [("lui", hi)]
    if lo != 0:
        parts.append(("addi", lo))
    return parts


def split_args(rest):
    return [a.strip() for a in rest.split(",")] if rest.strip() else []


def mem_operand(tok):
    m = re.fullmatch(r"(.*)\((\s*[\w]+\s*)\)", tok.strip())
    if not m:
        raise AsmError(f"expected imm(reg), got '{tok}'")
    off = m.group(1).strip()
    return (num(off) if off else 0), reg(m.group(2))


def expand(mn, args):
    """Turn pseudo-instructions into (mnemonic, args) lists of real instructions."""
    A = args
    if mn == "nop":   return [("addi", ["x0", "x0", "0"])]
    if mn == "mv":    return [("addi", [A[0], A[1], "0"])]
    if mn == "not":   return [("xori", [A[0], A[1], "-1"])]
    if mn == "neg":   return [("sub", [A[0], "x0", A[1]])]
    if mn == "seqz":  return [("sltiu", [A[0], A[1], "1"])]
    if mn == "snez":  return [("sltu", [A[0], "x0", A[1]])]
    if mn == "sltz":  return [("slt", [A[0], A[1], "x0"])]
    if mn == "sgtz":  return [("slt", [A[0], "x0", A[1]])]
    if mn == "beqz":  return [("beq", [A[0], "x0", A[1]])]
    if mn == "bnez":  return [("bne", [A[0], "x0", A[1]])]
    if mn == "blez":  return [("bge", ["x0", A[0], A[1]])]
    if mn == "bgez":  return [("bge", [A[0], "x0", A[1]])]
    if mn == "bltz":  return [("blt", [A[0], "x0", A[1]])]
    if mn == "bgtz":  return [("blt", ["x0", A[0], A[1]])]
    if mn == "bgt":   return [("blt", [A[1], A[0], A[2]])]
    if mn == "ble":   return [("bge", [A[1], A[0], A[2]])]
    if mn == "bgtu":  return [("bltu", [A[1], A[0], A[2]])]
    if mn == "bleu":  return [("bgeu", [A[1], A[0], A[2]])]
    if mn == "j":     return [("jal", ["x0", A[0]])]
    if mn == "jr":    return [("jalr", ["x0", "0(" + A[0] + ")"])]
    if mn == "ret":   return [("jalr", ["x0", "0(ra)"])]
    if mn == "li":
        return [(k, [A[0], "x0", str(v)] if (k == "addi" and i == 0) else
                     ([A[0], str(v)] if k == "lui" else [A[0], A[0], str(v)]))
                for i, (k, v) in enumerate(li_parts(num(A[1])))]
    return [(mn, A)]


def assemble(text):
    """Returns list of (pc, word, source-line)."""
    # ---- pass 1: labels, sizes
    items, labels, pc = [], {}, 0
    for lineno, raw in enumerate(text.splitlines(), 1):
        line = raw.split("#")[0].strip()
        while True:
            m = re.match(r"^([A-Za-z_.$][\w.$]*)\s*:\s*(.*)$", line)
            if not m:
                break
            if m.group(1) in labels:
                raise AsmError(f"line {lineno}: duplicate label {m.group(1)}")
            labels[m.group(1)] = pc
            line = m.group(2).strip()
        if not line:
            continue
        mn, _, rest = line.partition(" ")
        mn = mn.lower()
        args = split_args(rest.strip())
        try:
            if mn == ".word":
                for a in args:
                    items.append((pc, ".word", [a], raw.strip(), lineno))
                    pc += 4
            else:
                for m2, a2 in expand(mn, args):
                    items.append((pc, m2, a2, raw.strip(), lineno))
                    pc += 4
        except (AsmError, IndexError) as e:
            raise AsmError(f"line {lineno}: '{raw.strip()}': {e}")

    # ---- pass 2: encode
    out = []
    for pc, mn, A, raw, lineno in items:
        try:
            if mn == ".word":
                w = num(A[0]) & 0xFFFFFFFF
            elif mn in R_OPS:
                f3, f7 = R_OPS[mn]
                w = e_r(f3, f7, reg(A[0]), reg(A[1]), reg(A[2]))
            elif mn in I_OPS:
                w = e_i(OP_IMM, I_OPS[mn], reg(A[0]), reg(A[1]), num(A[2]))
            elif mn in SH_OPS:
                f3, f7 = SH_OPS[mn]
                w = e_shift(f3, f7, reg(A[0]), reg(A[1]), num(A[2]))
            elif mn in LD_OPS:
                off, rs1 = mem_operand(A[1])
                w = e_i(OP_LD, LD_OPS[mn], reg(A[0]), rs1, off)
            elif mn in ST_OPS:
                off, rs1 = mem_operand(A[1])
                w = e_s(ST_OPS[mn], reg(A[0]), rs1, off)
            elif mn in BR_OPS:
                tgt = labels[A[2]] - pc if A[2] in labels else num(A[2])
                w = e_b(BR_OPS[mn], reg(A[0]), reg(A[1]), tgt)
            elif mn == "lui":
                w = e_u(OP_LUI, reg(A[0]), num(A[1]))
            elif mn == "auipc":
                w = e_u(OP_AUIPC, reg(A[0]), num(A[1]))
            elif mn == "jal":
                if len(A) == 1:
                    A = ["ra", A[0]]
                tgt = labels[A[1]] - pc if A[1] in labels else num(A[1])
                w = e_j(reg(A[0]), tgt)
            elif mn == "jalr":
                if len(A) == 1:
                    rd, off, rs1 = 1, 0, reg(A[0])
                elif len(A) == 2:
                    rd = reg(A[0])
                    off, rs1 = mem_operand(A[1]) if "(" in A[1] else (0, reg(A[1]))
                else:
                    rd, rs1, off = reg(A[0]), reg(A[1]), num(A[2])
                w = e_i(OP_JALR, 0, rd, rs1, off)
            elif mn == "fence":
                w = 0x0FF0000F
            elif mn == "ecall":
                w = 0x00000073
            elif mn == "ebreak":
                w = 0x00100073
            else:
                raise AsmError(f"unsupported instruction '{mn}'")
        except KeyError as e:
            raise AsmError(f"line {lineno}: '{raw}': undefined label {e}")
        except (AsmError, IndexError) as e:
            raise AsmError(f"line {lineno}: '{raw}': {e}")
        out.append((pc, w, raw))
    return out


def to_bytes(words):
    b = bytearray()
    for _, w, _ in words:
        b += w.to_bytes(4, "little")
    return bytes(b)


def write_hex(words, path):
    with open(path, "w") as f:
        for byte in to_bytes(words):
            f.write(f"{byte:02X}\n")


def main():
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    try:
        words = assemble(open(sys.argv[1]).read())
    except AsmError as e:
        sys.exit(f"error: {e}")
    write_hex(words, sys.argv[2])
    for pc, w, raw in words:
        print(f"0x{pc:04x}: {w:08x}   {raw}")


if __name__ == "__main__":
    main()
