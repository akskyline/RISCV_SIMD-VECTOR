#!/usr/bin/env python3
"""Cross-check rv32_asm.py against the GNU RISC-V assembler (riscv*-unknown-elf-as), byte for byte.
   Needs binutils for riscv (e.g. `apt install binutils-riscv64-unknown-elf`, or the xPack toolchain)."""
import glob, os, random, shutil, subprocess, sys, tempfile
sys.path.insert(0, os.path.dirname(__file__))
import rv32_asm

AS = shutil.which("riscv64-unknown-elf-as") or shutil.which("riscv32-unknown-elf-as") or shutil.which("riscv-none-elf-as")
OC = shutil.which("riscv64-unknown-elf-objcopy") or shutil.which("riscv32-unknown-elf-objcopy") or shutil.which("riscv-none-elf-objcopy")
if not AS or not OC:
    sys.exit("GNU RISC-V binutils not found")

rnd = random.Random(1234)
R = [f"x{i}" for i in range(32)]
IMM12 = [0, 1, -1, 2047, -2048, 5, -5, 0x7f, -0x80, 1234, -1234]
lines = []
def any_reg(): return rnd.choice(R)
for mn in "add sub sll slt sltu xor srl sra or and".split():
    for _ in range(12): lines.append(f"{mn} {any_reg()}, {any_reg()}, {any_reg()}")
for mn in "addi slti sltiu xori ori andi".split():
    for v in IMM12: lines.append(f"{mn} {any_reg()}, {any_reg()}, {v}")
for mn in "slli srli srai".split():
    for v in (0, 1, 15, 16, 30, 31): lines.append(f"{mn} {any_reg()}, {any_reg()}, {v}")
for mn in "lb lh lw lbu lhu".split():
    for v in IMM12: lines.append(f"{mn} {any_reg()}, {v}({any_reg()})")
for mn in "sb sh sw".split():
    for v in IMM12: lines.append(f"{mn} {any_reg()}, {v}({any_reg()})")
for mn in ("lui", "auipc"):
    for v in (0, 1, 0x7FFFF, 0x80000, 0xFFFFF, 0x12345, 0xABCDE): lines.append(f"{mn} {any_reg()}, {v}")
for mn in "jalr".split():
    for v in IMM12: lines.append(f"jalr {any_reg()}, {v}({any_reg()})")
lines += ["jalr x5", "jalr ra, 0(x7)", "jalr x0, x9", "fence", "ecall", "ebreak", "nop", "ret", "jr x6", "jr ra"]
# ABI names
lines += ["add a0, a1, a2", "addi sp, sp, -16", "lw ra, 12(sp)", "sw s0, 8(sp)", "mv t0, t1", "add fp, s1, s11", "sub tp, gp, zero"]
# pseudos
for v in (0, 1, -1, 2047, -2048, 2048, -2049, 0x7FFFFFFF, 0x80000000, 0xFFFFFFFF, 0x12345678, 0xFFFFF800, 0x800, 0xFFF, 0xFFFFF000, 0xDEADBEEF, 0x7FF, 0x1000):
    lines.append(f"li {any_reg()}, {v}")
lines += ["mv x3, x4", "not x5, x6", "neg x7, x8", "seqz x9, x10", "snez x11, x12", "sltz x13, x14", "sgtz x15, x16"]
# control flow with labels (forward, backward, self)
body = []
for i in range(6):
    body.append(f"L{i}:")
    for mn in "beq bne blt bge bltu bgeu".split():
        tgt = rnd.choice([f"L{j}" for j in range(6)] + ["Lend"])
        body.append(f"{mn} {any_reg()}, {any_reg()}, {tgt}")
    for mn in "beqz bnez blez bgez bltz bgtz".split():
        body.append(f"{mn} {any_reg()}, {rnd.choice([f'L{j}' for j in range(6)] + ['Lend'])}")
    for mn in "bgt ble bgtu bleu".split():
        body.append(f"{mn} {any_reg()}, {any_reg()}, {rnd.choice([f'L{j}' for j in range(6)] + ['Lend'])}")
    body.append(f"jal {any_reg()}, {rnd.choice([f'L{j}' for j in range(6)] + ['Lend'])}")
    body.append(f"j {rnd.choice([f'L{j}' for j in range(6)] + ['Lend'])}")
    body.append("jal " + rnd.choice([f"L{j}" for j in range(6)]))
body.append("Lend: nop")
lines += body
lines += [".word 0xdeadbeef", ".word 0", ".word 0xffffffff"]

src = "\n".join(lines) + "\n"
mine = rv32_asm.to_bytes(rv32_asm.assemble(src))
with tempfile.TemporaryDirectory() as d:
    open(f"{d}/t.s", "w").write(".text\n" + src)
    subprocess.run([AS, "-march=rv32i", "-mabi=ilp32", "-mno-relax", f"{d}/t.s", "-o", f"{d}/t.o"], check=True)
    subprocess.run([OC, "-O", "binary", "-j", ".text", f"{d}/t.o", f"{d}/t.bin"], check=True)
    gnu = open(f"{d}/t.bin", "rb").read()
n = len(mine) // 4
if mine == gnu:
    print(f"OK: {len(lines)} source lines -> {n} words, identical to GNU as")
else:
    print(f"MISMATCH: mine {len(mine)} bytes, gnu {len(gnu)} bytes")
    for i in range(min(len(mine), len(gnu)) // 4):
        a, b = mine[4*i:4*i+4], gnu[4*i:4*i+4]
        if a != b:
            print(f"  word {i} (pc=0x{4*i:x}): mine={a[::-1].hex()} gnu={b[::-1].hex()}")
            break
    sys.exit(1)
