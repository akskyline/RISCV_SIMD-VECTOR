# ModelSim regression.  From the project folder (the one that contains rtl/, tb/, hex/, soc/):
#     do scripts/run_modelsim.do
# Every hex/*.hex program is run through the lockstep testbench (DUT vs reference model); then the
# coprocessor unit test and the SoC test.  Look for  "RESULT PASS" / "TEST PASSED"  in the transcript.
quit -sim
if {[file exists work]} { vdel -lib work -all }
vlib work
vlog -sv +incdir+rtl rtl/*.sv tb/*.sv

set fd [open hex/manifest.txt r]
set lines [split [read $fd] "\n"]
close $fd
set summary {}
foreach line $lines {
    if {$line eq ""} continue
    lassign $line name cause
    set args [list +HEX=hex/$name.hex +QUIET]
    if {$cause ne "-"} { lappend args +EXPECT_CAUSE=$cause }
    vsim -onfinish stop -c work.rv32i_tb {*}$args
    run -all
    quit -sim
}

vsim -onfinish stop -c work.vec_coproc_tb
run -all
quit -sim

vsim -onfinish stop -c work.riscv_soc_tb +HEX=soc/ins_little_endian.hex
run -all
quit -sim
echo "==== done: check the transcript for any FAIL / TEST FAILED ===="
