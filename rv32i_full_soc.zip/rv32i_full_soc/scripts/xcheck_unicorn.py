#!/usr/bin/env python3
"""
Independent cross-check: run a program in the Unicorn (QEMU-derived) RISC-V 32-bit emulator and compare
the final registers and data memory with what the RTL produced.  pip install unicorn

The emulator has ONE flat memory, the RTL has separate instruction / data memories, so programs that
touch data memory must keep code below 0x2000 and data inside 0x2000..0x2FFF (all generated / directed
tests do; a longer program that never stores, like t_alu, only has its registers compared).
The program is run until it reaches its final instruction (the ECALL).
"""
import sys
from unicorn import Uc, UC_ARCH_RISCV, UC_MODE_RISCV32
from unicorn.riscv_const import UC_RISCV_REG_X0

DATA_LO, DATA_HI = 0x2000, 0x3000


def load_hex(path):
    b = bytearray()
    for line in open(path):
        line = line.strip()
        if line:
            b.append(int(line, 16))
    return bytes(b)


def run(hexfile):
    code = load_hex(hexfile)
    if len(code) > 0xF000:
        raise ValueError("program too large for the emulator memory map")
    uc = Uc(UC_ARCH_RISCV, UC_MODE_RISCV32)
    uc.mem_map(0, 0x10000)
    uc.mem_write(0, code)
    last = len(code) - 4                                 # address of the final ECALL
    uc.emu_start(0, last, count=2_000_000)
    regs = {i: uc.reg_read(UC_RISCV_REG_X0 + i) for i in range(1, 32)}
    mem = {}
    if len(code) <= DATA_LO:                             # data window does not overlap the code
        data = uc.mem_read(DATA_LO, DATA_HI - DATA_LO)
        for i in range(0, len(data), 4):
            w = int.from_bytes(data[i:i + 4], "little")
            if w:
                mem[DATA_LO + i] = w
    return regs, mem


def compare(hexfile, dut_regs, dut_mem):
    try:
        regs, mem = run(hexfile)
    except Exception as e:                                # noqa
        return False, f"unicorn failed: {e}"
    for i in range(1, 32):
        if dut_regs.get(i) != regs[i]:
            return False, f"x{i}: rtl={dut_regs.get(i, 0):08x} unicorn={regs[i]:08x}"
    for a in sorted(set(dut_mem) | set(mem)):
        if dut_mem.get(a, 0) != mem.get(a, 0):
            return False, f"mem[{a:#x}]: rtl={dut_mem.get(a, 0):08x} unicorn={mem.get(a, 0):08x}"
    return True, ""


if __name__ == "__main__":
    r, m = run(sys.argv[1])
    for i in range(1, 32):
        print(f"x{i} {r[i]:08x}")
