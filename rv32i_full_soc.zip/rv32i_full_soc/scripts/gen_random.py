#!/usr/bin/env python3
"""
Constrained-random RV32I program generator.

Every generated program is legal and terminates: only forward branches / jumps (plus small
counted loops), all data accesses are naturally aligned and stay inside a 2 KB window at 0x2000
(x31 holds the base), and it ends with ECALL. Every item has a FIXED number of instructions
(no value-dependent pseudo expansion), so the generator resolves branch / jump / auipc offsets itself.

    python3 gen_random.py <seed> [items] > prog.S
"""
import random
import sys

CORNERS = [0, 1, 0xFFFFFFFF, 0x7FFFFFFF, 0x80000000, 0x80000001, 0x0000FFFF, 0xFFFF0000, 0x000000FF, 0xFFFFFF00,
           0x55555555, 0xAAAAAAAA, 0x12345678, 31, 32, 0xFFFFFFE0]
DEST = list(range(1, 31))          # never x31 (data base)
SRC = list(range(0, 32))


def hi_lo(v):
    v &= 0xFFFFFFFF
    hi = ((v + 0x800) >> 12) & 0xFFFFF
    lo = v - (hi << 12)
    lo = ((lo + (1 << 31)) & 0xFFFFFFFF) - (1 << 31)
    return hi, lo


def generate(seed, length=300):
    r = random.Random(seed)

    def val():
        return r.choice(CORNERS) if r.random() < 0.5 else r.getrandbits(32)

    def rd():   return r.choice(DEST + [0]) if r.random() < 0.06 else r.choice(DEST)
    def rs():   return r.choice(SRC)

    items = []          # each item: list of instruction "templates"; str, or callable(addr_of_this_instr, layout)->str

    def li_fixed(reg):
        v = val()
        hi, lo = hi_lo(v)
        return [f"lui x{reg}, {hi}", f"addi x{reg}, x{reg}, {lo}"]

    # ---- prologue: data base + random register init
    items.append(["lui x31, 2"])
    for reg in range(1, 31):
        items.append(li_fixed(reg))
    n_prologue = len(items)

    kinds = (["alu_r"] * 26 + ["alu_i"] * 18 + ["shift_i"] * 8 + ["upper"] * 6 + ["load"] * 11 + ["store"] * 11 +
             ["branch"] * 9 + ["jal"] * 3 + ["jalr"] * 3 + ["li"] * 4 + ["loop"] * 2 + ["fence"] + ["nop"])
    for _ in range(length):
        k = r.choice(kinds)
        if k == "alu_r":
            mn = r.choice("add sub sll slt sltu xor srl sra or and".split())
            items.append([f"{mn} x{rd()}, x{rs()}, x{rs()}"])
        elif k == "alu_i":
            mn = r.choice("addi slti sltiu xori ori andi".split())
            imm = r.choice([0, 1, -1, 2047, -2048, 31, 32]) if r.random() < 0.5 else r.randint(-2048, 2047)
            items.append([f"{mn} x{rd()}, x{rs()}, {imm}"])
        elif k == "shift_i":
            mn = r.choice("slli srli srai".split())
            items.append([f"{mn} x{rd()}, x{rs()}, {r.choice([0, 1, 15, 16, 30, 31, r.randint(0, 31)])}"])
        elif k == "upper":
            items.append([f"{r.choice(['lui', 'auipc'])} x{rd()}, {r.choice([0, 1, 0x7FFFF, 0x80000, 0xFFFFF, r.getrandbits(20)])}"])
        elif k == "load":
            mn = r.choice("lb lh lw lbu lhu".split())
            size = {"lb": 1, "lbu": 1, "lh": 2, "lhu": 2, "lw": 4}[mn]
            off = r.randrange(0, 0x800, size)
            items.append([f"{mn} x{rd()}, {off}(x31)"])
        elif k == "store":
            mn = r.choice("sb sh sw".split())
            size = {"sb": 1, "sh": 2, "sw": 4}[mn]
            off = r.randrange(0, 0x800, size)
            items.append([f"{mn} x{rs()}, {off}(x31)"])
        elif k == "li":
            items.append(li_fixed(rd()))
        elif k == "branch":
            mn = r.choice("beq bne blt bge bltu bgeu".split())
            a = rs(); b = a if r.random() < 0.15 else rs()
            items.append([("branch", mn, a, b, r.randint(1, 4))])
        elif k == "jal":
            items.append([("jal", rd(), r.randint(1, 4))])
        elif k == "jalr":
            items.append([("jalr", rd(), r.randint(1, 4), r.choice([0, 1, -1, 3, -3, 8, -8, 15]))])
        elif k == "loop":
            n = r.randint(1, 4)
            items.append([f"addi x29, x0, {n}", ("loop", 4), f"addi x29, x29, -1", f"add x{r.choice([d for d in DEST if d != 29])}, x{rs()}, x29", ("bnez_back",)])
        elif k == "fence":
            items.append(["fence"])
        else:
            items.append(["addi x0, x0, 0"])
    items.append(["ecall"])

    # ---- layout: address of every instruction / start of every item
    starts, addr = [], 0
    for it in items:
        starts.append(addr)
        def size(t):
            if isinstance(t, tuple):
                return 0 if t[0] == "loop" else (3 if t[0] == "jalr" else 1)
            return 1
        addr += 4 * sum(size(t) for t in it)
    n_items = len(items)

    out = [f"# random program, seed={seed}, items={length}   (generated - do not edit)"]
    for idx, it in enumerate(items):
        a = starts[idx]
        for t in it:
            if isinstance(t, str):
                out.append(f"        {t}")
                a += 4
            elif t[0] == "loop":
                loop_top = a                     # marker only (emits nothing)
                cur_loop_top = a
            elif t[0] == "bnez_back":
                out.append(f"        bne  x29, x0, {cur_loop_top - a}")
                a += 4
            elif t[0] == "branch":
                _, mn, x, y, skip = t
                tgt = starts[min(idx + 1 + skip, n_items - 1)]
                out.append(f"        {mn:<4} x{x}, x{y}, {tgt - a}")
                a += 4
            elif t[0] == "jal":
                _, reg, skip = t
                tgt = starts[min(idx + 1 + skip, n_items - 1)]
                out.append(f"        jal  x{reg}, {tgt - a}")
                a += 4
            elif t[0] == "jalr":
                # auipc x30,0 ; addi x30,x30,(T|b)-k-A ; jalr rd,k(x30)   -> target T (bit0 of the sum is cleared by jalr)
                _, reg, skip, k = t
                T = starts[min(idx + 1 + skip, n_items - 1)]
                A = a
                tgt_sum = T | (1 if (k % 2) else 0)          # odd immediate => sum is odd => jalr clears bit 0
                out.append(f"        auipc x30, 0")
                out.append(f"        addi x30, x30, {tgt_sum - k - A}")
                out.append(f"        jalr x{reg}, {k}(x30)")
                a += 12
    return "\n".join(out) + "\n"


if __name__ == "__main__":
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    n = int(sys.argv[2]) if len(sys.argv) > 2 else 300
    sys.stdout.write(generate(seed, n))
