#!/usr/bin/env python3
"""
Regression runner: assembles each test, runs the lockstep testbench (DUT vs reference model),
and reports PASS / FAIL, plus an instruction-coverage summary.

  python3 scripts/regress.py                      # directed + trap tests (Icarus Verilog)
  python3 scripts/regress.py --random 50          # + 50 random programs
  python3 scripts/regress.py --sim modelsim       # use ModelSim (vlog / vsim -c) instead of Icarus
  python3 scripts/regress.py --only t_mem,trap_   # name filter (comma separated substrings)

  --xcheck   also execute every program in the Unicorn (QEMU-based) RV32 emulator and compare the
             final registers / data memory with the RTL   (pip install unicorn)
"""
import argparse, glob, os, re, shutil, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import rv32_asm

ap = argparse.ArgumentParser()
ap.add_argument("--sim", default="iverilog", choices=["iverilog", "modelsim"])
ap.add_argument("--random", type=int, default=0, help="number of random programs")
ap.add_argument("--length", type=int, default=300, help="random program size (items)")
ap.add_argument("--seed0", type=int, default=1)
ap.add_argument("--only", default="")
ap.add_argument("--xcheck", action="store_true")
ap.add_argument("--work", default=os.path.join(ROOT, "sim", "regress"))
args = ap.parse_args()

W = os.path.abspath(args.work)
shutil.rmtree(W, ignore_errors=True)
os.makedirs(W)
RTL = [os.path.join(ROOT, "rtl", f) for f in ("rv32i_core_modules.sv", "rv32i_memories.sv", "sgle_cyc_processor.sv")]
TB = [os.path.join(ROOT, "tb", "rv32i_iss.sv"), os.path.join(ROOT, "tb", "rv32i_tb.sv")]

# ---- build once
if args.sim == "iverilog":
    c = subprocess.run(["iverilog", "-g2012", "-I", os.path.join(ROOT, "rtl"), "-s", "rv32i_tb", "-o", f"{W}/sim.vvp"] + RTL + TB,
                       capture_output=True, text=True)
    if c.returncode:
        sys.exit(c.stderr)
    RUN = lambda hexf, extra: subprocess.run(["vvp", f"{W}/sim.vvp", f"+HEX={hexf}", "+QUIET", "+COV", "+MAXCYC=60000"] + extra,
                                             capture_output=True, text=True, cwd=W, timeout=120).stdout
else:
    subprocess.run(["vlib", f"{W}/work"], check=True, capture_output=True)
    c = subprocess.run(["vlog", "-work", f"{W}/work", "-sv", f"+incdir+{os.path.join(ROOT, 'rtl')}"] + RTL + TB,
                       capture_output=True, text=True)
    if "Errors: 0" not in c.stdout:
        sys.exit(c.stdout + c.stderr)
    RUN = lambda hexf, extra: subprocess.run(["vsim", "-c", "-lib", f"{W}/work", "rv32i_tb", f"+HEX={hexf}", "+QUIET", "+COV"] + extra +
                                             ["-do", "run -all; quit -f"], capture_output=True, text=True, cwd=W).stdout

def run_program(name, hexf, extra=()):
    out = RUN(hexf, list(extra))
    m = re.search(r"RESULT (PASS|FAIL)", out)
    fails = [l for l in out.splitlines() if "[FAIL" in l][:3]
    cov = {mm.group(1): int(mm.group(2)) for mm in re.finditer(r"^COV (\w+) (\d+)", out, re.M)}
    regs = {int(mm.group(1)): int(mm.group(2), 16) for mm in re.finditer(r"^REG x(\d+) ([0-9a-fA-F]+)", out, re.M)}
    mem = {int(mm.group(1), 16): int(mm.group(2), 16) for mm in re.finditer(r"^MEM ([0-9a-fA-F]+) ([0-9a-fA-F]+)", out, re.M)}
    fin = re.search(r"FINAL pc=(\w+) halted=(\d) cause=(-?\d+) retired=(\d+)", out)
    return (m and m.group(1) == "PASS"), fails, cov, regs, mem, fin, out

tests = []
for f in sorted(glob.glob(os.path.join(ROOT, "tests", "*.S"))):
    tests.append((os.path.basename(f)[:-2], open(f).read()))
if args.random:
    import gen_random
    for s in range(args.seed0, args.seed0 + args.random):
        tests.append((f"rand_{s}", gen_random.generate(s, args.length)))
if args.only:
    keys = args.only.split(",")
    tests = [t for t in tests if any(k in t[0] for k in keys)]

total_cov, nfail, rows = {}, 0, []
if args.xcheck:
    import xcheck_unicorn
for name, src in tests:
    hexf = f"{W}/{name}.hex"
    rv32_asm.write_hex(rv32_asm.assemble(src), hexf)
    extra = []
    m = re.search(r"expected trap cause (\d+)", src)
    expect_note = ""
    if m:
        extra.append(f"+EXPECT_CAUSE={m.group(1)}")
        expect_note = f" (trap cause {m.group(1)})"
    ok, fails, cov, regs, mem, fin, out = run_program(name, hexf, extra)
    xnote = ""
    if ok and args.xcheck and not m and 'noxcheck' not in src:
        okx, why = xcheck_unicorn.compare(hexf, regs, mem)
        if not okx:
            ok, xnote = False, f"   UNICORN MISMATCH: {why}"
        else:
            xnote = "  +unicorn"
    for k, v in cov.items():
        total_cov[k] = total_cov.get(k, 0) + v
    nfail += (not ok)
    print(f"{'PASS' if ok else 'FAIL'}  {name:<28} retired={fin.group(4) if fin else '?':>6}{expect_note}{xnote}")
    if not ok:
        for l in fails: print("      ", l)
        if not fails and not xnote: print("       (no RESULT line - tail of log:)", out[-300:])

names = ["lui","auipc","jal","jalr","beq","bne","blt","bge","bltu","bgeu","lb","lh","lw","lbu","lhu","sb","sh","sw",
         "addi","slti","sltiu","xori","ori","andi","slli","srli","srai","add","sub","sll","slt","sltu","xor","srl","sra","or","and",
         "fence","ecall","ebreak"]
missing = [n for n in names if total_cov.get(n, 0) == 0]
print(f"\n{len(tests)} programs, {nfail} failed")
print(f"instruction coverage: {len(names) - len(missing)}/{len(names)} RV32I instructions executed" +
      (f"   NOT executed: {missing}" if missing else ""))
print("illegal-instruction retires:", total_cov.get("illegal", 0))
sys.exit(1 if nfail else 0)
