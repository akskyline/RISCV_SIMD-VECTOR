#!/usr/bin/env python3
"""
Mutation test of the verification environment: inject ONE deliberate bug into the RTL at a time and
check that the regression notices.  A mutant that survives means a hole in the tests.
    python3 scripts/mutation_test.py
"""
import glob, os, re, shutil, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import rv32_asm, gen_random

M = [   # (name, file, original text, mutated text)
 ("slt_unsigned",       "rv32i_core_modules.sv", "($signed(RD1) < $signed(srcb)) ? 32'd1", "(RD1 < srcb) ? 32'd1"),
 ("sltu_signed",        "rv32i_core_modules.sv", "(RD1 < srcb)                   ? 32'd1", "($signed(RD1) < $signed(srcb)) ? 32'd1"),
 ("sra_logical",        "rv32i_core_modules.sv", "$signed(RD1) >>> srcb[4:0]", "RD1 >> srcb[4:0]"),
 ("srl_arith",          "rv32i_core_modules.sv", "alu_result = RD1 >> srcb[4:0];", "alu_result = $signed(RD1) >>> srcb[4:0];"),
 ("shamt_6bit",         "rv32i_core_modules.sv", "alu_result = RD1 << srcb[4:0];", "alu_result = RD1 << srcb[5:0];"),
 ("addi_as_sub",        "rv32i_core_modules.sv", "(opcode[5] & ins[30]) ? `RV_ALU_SUB", "(ins[30]) ? `RV_ALU_SUB"),
 ("blt_unsigned",       "rv32i_core_modules.sv", "3'b100:  cond =  br_lt;", "3'b100:  cond =  br_ltu;"),
 ("bge_wrong",          "rv32i_core_modules.sv", "3'b101:  cond = ~br_lt;", "3'b101:  cond = ~br_ltu;"),
 ("bne_is_beq",         "rv32i_core_modules.sv", "3'b001:  cond = ~br_eq;", "3'b001:  cond =  br_eq;"),
 ("bltu_signed",        "rv32i_core_modules.sv", "3'b110:  cond =  br_ltu;", "3'b110:  cond =  br_lt;"),
 ("jalr_keeps_bit0",    "rv32i_core_modules.sv", "{jalr_target[31:1], 1'b0}", "jalr_target"),
 ("jal_link_is_pc",     "rv32i_core_modules.sv", "`RV_RES_PC4:   WD = pcplus_4;", "`RV_RES_PC4:   WD = pc_target;"),
 ("lb_no_signext",      "rv32i_core_modules.sv", "3'b000:  begin result = {{24{b[7]}},  b};", "3'b000:  begin result = {24'd0,  b};"),
 ("lhu_signext",        "rv32i_core_modules.sv", "3'b101:  begin result = {16'd0, h};", "3'b101:  begin result = {{16{h[15]}}, h};"),
 ("sb_wrong_lane",      "rv32i_core_modules.sv", "be = 4'b0001 << addr_lsb;              end\n            2'b01", "be = 4'b0001;              end\n            2'b01"),
 ("sh_wrong_half",      "rv32i_core_modules.sv", "be = addr_lsb[1] ? 4'b1100 : 4'b0011; end\n            default", "be = 4'b0011; end\n            default"),
 ("lui_adds_pc",        "rv32i_core_modules.sv", "`RV_RES_IMM:   WD = imm;", "`RV_RES_IMM:   WD = pc_target;"),
 ("auipc_no_pc",        "rv32i_core_modules.sv", "`RV_RES_PCIMM: WD = pc_target;", "`RV_RES_PCIMM: WD = imm;"),
 ("x0_writable",        "rv32i_core_modules.sv", "if (regwrite && A3 != 5'd0)", "if (regwrite)"),
 ("op_funct7_ignored",  "rv32i_core_modules.sv", "if (!(f7 == 7'b0000000 ||", "if (1'b0 && !(f7 == 7'b0000000 ||"),
 ("no_fetch_misalign",  "rv32i_core_modules.sv", "assign fetch_mis = (pc_src != `RV_PC_NEXT) & (next_pc_lsb != 2'b00);", "assign fetch_mis = 1'b0;"),
 ("no_pc_freeze",       "rv32i_core_modules.sv", ".en(~trap_now), .pc_src(pc_src)", ".en(1'b1), .pc_src(pc_src)"),
 ("no_load_misalign",   "rv32i_core_modules.sv", "assign load_mis  = memread  & mis_data;", "assign load_mis  = 1'b0;"),
 ("trap_still_writes",  "rv32i_core_modules.sv", "assign regwrite = regwrite_c & ~trap_now;", "assign regwrite = regwrite_c;"),
 ("imm_b_bit11",        "rv32i_core_modules.sv", "{{19{ins[31]}}, ins[31], ins[7], ins[30:25], ins[11:8], 1'b0}", "{{19{ins[31]}}, ins[31], ins[20], ins[30:25], ins[11:8], 1'b0}"),
 ("imm_j_bit11",        "rv32i_core_modules.sv", "ins[19:12], ins[20], ins[30:21], 1'b0}", "ins[19:12], ins[7], ins[30:21], 1'b0}"),
 ("imm_s_low",          "rv32i_core_modules.sv", "{{20{ins[31]}}, ins[31:25], ins[11:7]}", "{{20{ins[31]}}, ins[31:25], ins[24:20]}"),
 ("fencei_accepted",    "rv32i_core_modules.sv", "if (f3 != 3'b000) illegal = 1'b1;        // FENCE.I", "if (1'b0) illegal = 1'b1;        // FENCE.I"),
 ("ecall_not_trap",     "rv32i_core_modules.sv", "if      (ins == 32'h0000_0073) ecall  = 1'b1;", "if      (ins == 32'h0000_0073) ecall  = 1'b0;"),
 ("slli_f7_unchecked",  "rv32i_core_modules.sv", "if (f3 == 3'b001 && f7 != 7'b0000000)", "if (1'b0)"),
 ("branch_f3_010_ok",   "rv32i_core_modules.sv", "3'b000, 3'b001, 3'b100, 3'b101, 3'b110, 3'b111: begin\n                            imm_src = `RV_IMM_B;", "3'b000, 3'b001, 3'b010, 3'b100, 3'b101, 3'b110, 3'b111: begin\n                            imm_src = `RV_IMM_B;"),
 ("rvfi_rd_wrong",      "rv32i_core_modules.sv", "r.rd_wdata  = rd_wr ? W_Data : 32'd0;", "r.rd_wdata  = rd_wr ? alu_result : 32'd0;"),
 ("rvfi_pcwdata_wrong", "rv32i_core_modules.sv", "r.pc_wdata  = trap_now ? pc : pc_next;", "r.pc_wdata  = trap_now ? pc : pcplus_4;"),
]

W = os.path.join(ROOT, "sim", "mut"); shutil.rmtree(W, ignore_errors=True); os.makedirs(W)
tests = [("t_alu", open(f"{ROOT}/tests/t_alu.S").read()), ("t_ctrl", open(f"{ROOT}/tests/t_ctrl.S").read()),
         ("t_mem", open(f"{ROOT}/tests/t_mem.S").read()), ("t_upper", open(f"{ROOT}/tests/t_upper.S").read())]
tests += [(os.path.basename(f)[:-2], open(f).read()) for f in sorted(glob.glob(f"{ROOT}/tests/trap_*.S"))]
tests += [(f"rand_{s}", gen_random.generate(s, 250)) for s in range(1, 9)]
for n, src in tests:
    rv32_asm.write_hex(rv32_asm.assemble(src), f"{W}/{n}.hex")
if len(sys.argv) > 1: M = [m for m in M if any(a in m[0] for a in sys.argv[1:])]

survivors = 0
for name, f, old, new in M:
    d = f"{W}/{name}"; os.makedirs(d)
    for x in glob.glob(f"{ROOT}/rtl/*"): shutil.copy(x, d)
    s = open(f"{d}/{f}").read()
    if old not in s:
        print(f"{name:<22} PATTERN NOT FOUND"); survivors += 1; continue
    open(f"{d}/{f}", "w").write(s.replace(old, new, 1))
    srcs = [f"{d}/rv32i_core_modules.sv", f"{d}/rv32i_memories.sv", f"{d}/sgle_cyc_processor.sv", f"{ROOT}/tb/rv32i_iss.sv", f"{ROOT}/tb/rv32i_tb.sv"]
    c = subprocess.run(["iverilog", "-g2012", "-I", d, "-s", "rv32i_tb", "-o", f"{d}/m.vvp"] + srcs, capture_output=True, text=True)
    if c.returncode: print(f"{name:<22} COMPILE ERROR {c.stderr[:150]}"); survivors += 1; continue
    killed_by = None
    for n, src in tests:
        extra = []
        m = re.search(r"expected trap cause (\d+)", src)
        if m: extra.append(f"+EXPECT_CAUSE={m.group(1)}")
        try:
            out = subprocess.run(["vvp", f"{d}/m.vvp", f"+HEX={W}/{n}.hex", "+QUIET", "+MAXCYC=30000"] + extra,
                                 capture_output=True, text=True, timeout=120).stdout
        except subprocess.TimeoutExpired:
            killed_by = n + " (hang)"; break
        if "RESULT PASS" not in out:
            killed_by = n; break
    if killed_by: print(f"{name:<22} killed by {killed_by}")
    else: print(f"{name:<22} SURVIVED  <-- test hole"); survivors += 1
print(f"\n{len(M)} mutants, {survivors} survived")
sys.exit(1 if survivors else 0)
