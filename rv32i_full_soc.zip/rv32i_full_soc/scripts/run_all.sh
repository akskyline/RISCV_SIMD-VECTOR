#!/usr/bin/env bash
# Icarus Verilog runner: lockstep regression (directed + trap + random), coprocessor unit test, SoC test.
#   ./scripts/run_all.sh [number_of_random_programs]     (default 20)
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
N="${1:-20}"
RTL="$ROOT/rtl"
VEC="$RTL/vec_alu.sv $RTL/vec_regfile.sv $RTL/vec_coproc.sv"
FILTER='constant selects|Not enough words'
mkdir -p "$ROOT/sim/vec" "$ROOT/sim/soc"

echo "=========== 1) full RV32I lockstep regression (DUT vs reference model vs Unicorn) ==========="
python3 "$ROOT/scripts/regress.py" --random "$N" --xcheck | tail -6

echo "=========== 2) vector coprocessor unit test ==========="
( cd "$ROOT/sim/vec" && iverilog -g2012 -I "$RTL" -s vec_coproc_tb -o vec.vvp $VEC "$ROOT/tb/vec_coproc_tb.sv" 2>&1 | grep -Ev "$FILTER" || true
  vvp vec.vvp | grep -E "FAIL|errors +:|TEST (PASSED|FAILED)" )

echo "=========== 3) SoC: full RV32I core + memory-mapped vector coprocessor ==========="
cp "$ROOT/soc/ins_little_endian.hex" "$ROOT/sim/soc/"
( cd "$ROOT/sim/soc" && iverilog -g2012 -I "$RTL" -s riscv_soc_tb -o soc.vvp "$RTL/rv32i_core_modules.sv" "$RTL/rv32i_memories.sv" $VEC "$RTL/riscv_soc_top.sv" "$ROOT/tb/riscv_soc_tb.sv" 2>&1 | grep -Ev "$FILTER" || true
  vvp soc.vvp | grep -E "FAIL|errors +:|TEST (PASSED|FAILED)" )
