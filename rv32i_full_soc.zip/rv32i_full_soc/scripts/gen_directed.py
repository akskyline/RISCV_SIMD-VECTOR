#!/usr/bin/env python3
"""Generates the directed test programs into ../tests/*.S (checked in, re-run to regenerate).
   Every program ends with ECALL (clean halt, cause 11). Correctness is judged by the lockstep
   comparison against the reference model, so these programs only need to EXERCISE the corners."""
import os

OUT = os.path.join(os.path.dirname(__file__), "..", "tests")
os.makedirs(OUT, exist_ok=True)
CORNERS = [0, 1, 0xFFFFFFFF, 0x7FFFFFFF, 0x80000000, 0x12345678, 0xFFFF0000, 0x0000FFFF, 0x80000001, 5, 31, 32, 33, 0xFFFFFFE1]
IMMS = [0, 1, -1, 2047, -2048, 0x7F, -0x80, 1234, -1234, 31, 32]
SH = [0, 1, 2, 15, 16, 30, 31]

def w(path, lines):
    with open(os.path.join(OUT, path), "w") as f:
        f.write("\n".join(lines) + "\n")

# ---------------------------------------------------------------- ALU
L = ["# directed: every register-register and register-immediate ALU instruction, corner operands",
     "        # ---- R-type: all ops x all corner operand pairs"]
for a in CORNERS:
    for b in CORNERS:
        L += [f"        li   x1, {a:#x}", f"        li   x2, {b:#x}"]
        for mn in "add sub sll slt sltu xor srl sra or and".split():
            L.append(f"        {mn:<4} x3, x1, x2")
L.append("        # ---- I-type ALU with immediates")
for a in CORNERS:
    L.append(f"        li   x1, {a:#x}")
    for mn in "addi slti sltiu xori ori andi".split():
        for imm in IMMS:
            L.append(f"        {mn:<5} x4, x1, {imm}")
    for mn in "slli srli srai".split():
        for sh in SH:
            L.append(f"        {mn:<4} x5, x1, {sh}")
L += ["        # ---- destination x0 must stay 0 and source x0 reads 0",
      "        li   x1, 123", "        add  x0, x1, x1", "        addi x0, x1, 5", "        add  x6, x0, x1",
      "        sub  x7, x0, x1", "        lui  x0, 0x12345", "        add  x8, x0, x0",
      "        # ---- rd == rs1 == rs2 aliasing",
      "        li   x9, 0x80000001", "        add  x9, x9, x9", "        li   x9, 3", "        sll  x9, x9, x9",
      "        li   x9, -8", "        sra  x9, x9, x9", "        xor  x9, x9, x9",
      "        ecall"]
w("t_alu.S", L)

# ---------------------------------------------------------------- LUI/AUIPC
L = ["# directed: lui / auipc / li expansion corners"]
for v in [0, 1, 0x7FFFF, 0x80000, 0xFFFFF, 0x12345, 0xABCDE, 0x00800, 0x55555, 0xAAAAA]:
    L += [f"        lui   x1, {v:#x}", f"        auipc x2, {v:#x}", f"        add   x3, x1, x2"]
for v in [0x7FF, 0x800, 0x801, 0xFFF, 0x1000, 0x7FFFF7FF, 0x7FFFF800, 0x80000000, 0xFFFFF800, 0xFFFFF7FF, 0xDEADBEEF, 0x12345FFF, 0xFFFFFFFF, -2048, -2049, 2047, 2048]:
    L.append(f"        li    x4, {v}")
L += ["        auipc x5, 0", "        auipc x6, 0xFFFFF", "        ecall"]
w("t_upper.S", L)

# ---------------------------------------------------------------- memory
L = ["# directed: all load / store sizes, every byte lane, sign / zero extension, negative offsets",
     "        lui  x31, 2                 # x31 = 0x2000 data base",
     "        li   x1, 0x80FF7F01",
     "        li   x2, 0x8081FF7F",
     "        sw   x1, 0(x31)",
     "        sw   x2, 4(x31)"]
for off in range(0, 8):
    for mn in ("lb", "lbu"):
        L.append(f"        {mn:<3}  x3, {off}(x31)")
for off in (0, 2, 4, 6):
    for mn in ("lh", "lhu"):
        L.append(f"        {mn:<3}  x3, {off}(x31)")
for off in (0, 4):
    L.append(f"        lw   x3, {off}(x31)")
L += ["        # ---- byte stores into every lane of a word, then read back",
      "        sw   x0, 8(x31)", "        li   x1, 0x1122334F"]
for off in range(4):
    L += [f"        sb   x1, {8+off}(x31)", "        lw   x4, 8(x31)", "        addi x1, x1, 0x111"]
L += ["        # ---- halfword stores into both halves", "        sw   x0, 12(x31)", "        li   x1, 0xCAFEBABE"]
for off in (0, 2):
    L += [f"        sh   x1, {12+off}(x31)", "        lw   x4, 12(x31)", "        srli x1, x1, 8"]
L += ["        # ---- store then load through a different size", "        li x1, -1", "        sw x1, 16(x31)",
      "        sb x0, 17(x31)", "        lw x4, 16(x31)", "        lh x5, 16(x31)", "        lhu x6, 18(x31)",
      "        lb x7, 17(x31)", "        lbu x8, 19(x31)",
      "        # ---- negative offsets / far offsets from a moved base",
      "        addi x30, x31, 2040", "        sw   x1, -2040(x30)", "        lw   x4, -2040(x30)",
      "        sw   x1, 7(x30)" if False else "        sw   x1, 4(x30)", "        lw   x4, 4(x30)",
      "        addi x30, x31, -4", "        sw   x1, 4(x30)", "        lw x4, 4(x30)",
      "        # ---- rd = x0 load (no effect), rs2 = x0 store", "        lw x0, 0(x31)", "        sw x0, 20(x31)", "        lw x4, 20(x31)",
      "        # ---- loads where rd == rs1", "        lw x31, 0(x31)", "        ecall"]
w("t_mem.S", L)

# ---------------------------------------------------------------- control flow
L = ["# directed: all six branches x corner operands (taken and not taken), jal, jalr, loops"]
n = 0
pairs = [(0, 0), (1, 0), (0, 1), (0xFFFFFFFF, 1), (1, 0xFFFFFFFF), (0x80000000, 0x7FFFFFFF), (0x7FFFFFFF, 0x80000000),
         (0xFFFFFFFF, 0xFFFFFFFF), (5, 5), (0x80000000, 0x80000000), (0xFFFFFFFE, 0xFFFFFFFF), (3, 7), (7, 3)]
for mn in "beq bne blt bge bltu bgeu".split():
    for a, b in pairs:
        L += [f"        li   x1, {a:#x}", f"        li   x2, {b:#x}",
              f"        {mn:<4} x1, x2, T{n}", "        addi x10, x10, 1", f"T{n}:", "        addi x11, x11, 1"]
        n += 1
L += ["        # ---- backward branch: count down", "        li   x5, 5", "Lloop:", "        addi x5, x5, -1", "        addi x12, x12, 3", "        bnez x5, Lloop",
      "        # ---- branch whose target is misaligned but which is NOT taken: must not trap",
      "        li   x1, 1", "        li   x2, 2", "        beq  x1, x2, 6", "        addi x13, x0, 1",
      "        # ---- jal forward / link value", "        jal  x1, Lj1", "        addi x14, x0, 99", "Lj1:", "        addi x14, x14, 1",
      "        # ---- call / return with jalr", "        jal  ra, Lfun", "        addi x15, x15, 100", "        j    Lafter",
      "Lfun:", "        addi x15, x15, 7", "        ret", "Lafter:",
      "        # ---- jalr with an odd immediate: bit 0 of the target is cleared", "        auipc x6, 0", "        addi  x6, x6, 20", "        jalr  x7, -3(x6)", "        addi  x16, x0, 99", "        addi  x16, x16, 1",
      "        # ---- jalr with rd == rs1 and with rd = x0", "        auipc x8, 0", "        addi  x8, x8, 12", "        jalr  x8, 0(x8)", "        addi  x17, x0, 99", "        addi  x17, x17, 1",
      "        auipc x9, 0", "        addi  x9, x9, 12", "        jalr  x0, 0(x9)", "        addi  x18, x0, 99", "        addi  x18, x18, 1",
      "        # ---- fence is a no-op", "        fence", "        addi x19, x0, 5",
      "        ecall"]
w("t_ctrl.S", L)

# ---------------------------------------------------------------- traps (each ends the program)
TRAPS = {
    "trap_ecall.S":            ("ecall", 11),
    "trap_ebreak.S":           ("ebreak", 3),
    "trap_illegal_zero.S":     (".word 0x00000000", 2),
    "trap_illegal_ones.S":     (".word 0xffffffff", 2),
    "trap_illegal_opcode.S":   (".word 0x0000007b", 2),     # custom-3 opcode
    "trap_mul_is_illegal.S":   (".word 0x023100b3", 2),     # mul x1,x2,x3 (M extension) is not RV32I
    "trap_compressed.S":       (".word 0x00004501", 2),     # c.li encoding: low bits != 11
    "trap_fencei.S":           (".word 0x0000100f", 2),     # fence.i (Zifencei) not in base
    "trap_csr.S":              (".word 0x30047073", 2),     # csrrci
    "trap_slli_bad_f7.S":      (".word 0x02009093", 2),     # slli with funct7 = 0000001
    "trap_srai_bad_f7.S":      (".word 0x60105093", 2),     # srli/srai slot with funct7 = 0110000
    "trap_sub_bad_f3.S":       (".word 0x40209133", 2),     # funct7=0100000 with funct3=001
    "trap_bad_branch_f3.S":    (".word 0x00002063", 2),     # branch funct3 = 010
    "trap_bad_load_f3.S":      (".word 0x00003003", 2),     # load funct3 = 011 (LD, RV64)
    "trap_bad_store_f3.S":     (".word 0x00003023", 2),     # store funct3 = 011 (SD, RV64)
    "trap_bad_jalr_f3.S":      (".word 0x000090e7", 2),     # jalr funct3 = 001
    "trap_ecall_with_rd.S":    (".word 0x000000f3", 2),     # ecall encoding with rd != 0
    "trap_lw_misaligned.S":    ("lui x31, 2\n        lw x1, 2(x31)", 4),
    "trap_lh_misaligned.S":    ("lui x31, 2\n        lh x1, 1(x31)", 4),
    "trap_lhu_misaligned.S":   ("lui x31, 2\n        lhu x1, 3(x31)", 4),
    "trap_sw_misaligned.S":    ("lui x31, 2\n        li x1, 5\n        sw x1, 1(x31)", 6),
    "trap_sh_misaligned.S":    ("lui x31, 2\n        li x1, 5\n        sh x1, 3(x31)", 6),
    "trap_jalr_misaligned.S":  ("auipc x5, 0\n        addi x5, x5, 10\n        jalr x1, 0(x5)", 0),
    "trap_jal_misaligned.S":   ("jal x1, 6", 0),
    "trap_branch_misaligned.S":("li x1, 1\n        beq x1, x1, 6", 0),
    "trap_taken_bge_misaligned.S": ("li x1, 2\n        li x2, 1\n        bge x1, x2, -6", 0),
}
for name, (body, cause) in TRAPS.items():
    w(name, [f"# expected trap cause {cause}: the instruction must retire with trap=1, NO side effect, then the core halts",
             "        li   x20, 111", "        addi x21, x0, 222",
             f"        {body}",
             "        li   x22, 333            # must never execute",
             "        ecall"])
print("generated", len(os.listdir(OUT)), "files in", os.path.abspath(OUT))
