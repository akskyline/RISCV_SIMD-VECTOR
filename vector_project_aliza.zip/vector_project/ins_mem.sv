//instruction memory module
module ins_mem(input logic [31:0] addr,
output logic [31:0] instruction);

logic [7:0] ins_mem [0:4095];


initial begin
$readmemh("./ins_little_endian.hex",ins_mem); //("file", array_name, start_addr, end_addr)
end
assign instruction = {ins_mem[addr+3], ins_mem[addr+2], ins_mem[addr+1], ins_mem[addr]}; 
endmodule 
