`timescale 1ns/1ps
`include "vec_defs.svh"
// =============================================================================
// riscv_soc_tb - integration test: the RV32I core runs soc_prog.S and drives the
// vector coprocessor with ordinary lw/sw. Checks the end state of the core, the
// coprocessor's vector registers, and that the address decoder keeps SRAM and
// coprocessor traffic separate.
//
// Run from a directory containing ins_little_endian.hex built from soc_prog.S.
// =============================================================================
module riscv_soc_tb;

    localparam time CLK_PERIOD = 10;

    logic clk, rst;
    int errors = 0, checks = 0;

    riscv_soc_top dut (.clk(clk), .rst(rst));

    initial clk = 1'b0;
    always #(CLK_PERIOD/2) clk = ~clk;

    task automatic check_eq(input logic [31:0] got, input logic [31:0] exp, input string msg);
        checks++;
        if (got === exp) $display("[PASS] %-46s = 0x%08h (%0d)", msg, got, got);
        else begin
            errors++;
            $display("[FAIL] %-46s = 0x%08h, expected 0x%08h", msg, got, exp);
        end
    endtask

    // ------------------------------------------- bus trace of coprocessor accesses
    // (sampled just before the clock edge, like the hardware samples them)
    always @(posedge clk) begin
        if (!rst && dut.cp_sel) begin
            if (dut.memwrite)
                $display("[BUS %0t] pc=%03h  CPU -> COPROC  write off=0x%03h data=0x%08h",
                         $time, dut.pc[11:0], dut.alu_result[10:0], dut.RD2);
            else if (dut.result_src == 2'b01)
                $display("[BUS %0t] pc=%03h  CPU <- COPROC  read  off=0x%03h data=0x%08h",
                         $time, dut.pc[11:0], dut.alu_result[10:0], dut.RD_cp);
        end
    end

    // ---- count SRAM writes and coprocessor writes separately (data_mem PORTS only)
    int          sram_wr_cnt = 0, cp_wr_cnt = 0;
    logic [31:0] sram_last_a = 0, sram_last_d = 0;
    always @(posedge clk) begin
        if (!rst && dut.data_mem8.memwrite) begin
            sram_wr_cnt++;
            sram_last_a = dut.data_mem8.A;
            sram_last_d = dut.data_mem8.WD;
            $display("[SRAM %0t] write addr=0x%08h data=0x%08h", $time, dut.data_mem8.A, dut.data_mem8.WD);
        end
        if (!rst && dut.cp_sel && dut.memwrite) cp_wr_cnt++;
    end

    // completion of a coprocessor command
    logic busy_q, done_q;
    always @(posedge clk) begin
        busy_q <= dut.u_vec.busy;
        done_q <= dut.u_vec.done;
        if (dut.u_vec.busy && !busy_q) $display("[VEC %0t] EXEC start  op=%0d vd=v%0d vs1=v%0d vs2=v%0d vl=%0d",
                                                $time, dut.u_vec.op_r, dut.u_vec.vd_r, dut.u_vec.vs1_r,
                                                dut.u_vec.vs2_r, dut.u_vec.vl_r);
        if (dut.u_vec.done && !done_q) $display("[VEC %0t] DONE       err=%b result=0x%08h",
                                                $time, dut.u_vec.err, dut.u_vec.result_r);
    end

    // ---------------------------------------------------------------- main
    initial begin
        $timeformat(-9, 0, " ns", 8);
        $dumpfile("riscv_soc.vcd");
        $dumpvars(0, riscv_soc_tb);

        rst = 1;
        repeat (3) @(posedge clk);
        @(negedge clk) rst = 0;

        // program ends in `jal x0,0` (0x0000006F) - poll until it is being fetched
        begin
            int cyc;
            cyc = 0;
            while (dut.instruction !== 32'h0000006F && cyc < 3000) begin
                @(posedge clk);
                cyc++;
            end
            if (cyc >= 3000) begin
                $display("[FAIL] TIMEOUT - program never reached the halt loop, pc=0x%08h", dut.pc);
                errors++;
            end
            repeat (4) @(posedge clk);
        end

        $display("\n=== core register results ===");
        check_eq(dut.reg_file4.regfile[10], 32'h800, "x10 coprocessor base");
        check_eq(dut.reg_file4.regfile[4],  32'd11,  "x4  v3[0] read back over the bus (1+10)");
        check_eq(dut.reg_file4.regfile[5],  32'd22,  "x5  v3[1] (2+20)");
        check_eq(dut.reg_file4.regfile[6],  32'd33,  "x6  v3[2] (3+30)");
        check_eq(dut.reg_file4.regfile[7],  32'd44,  "x7  v3[3] (4+40)");
        check_eq(dut.reg_file4.regfile[2],  32'd2,   "x2  last STATUS poll = DONE");
        check_eq(dut.reg_file4.regfile[8],  32'd110, "x8  REDSUM(v3) = 11+22+33+44");
        check_eq(dut.reg_file4.regfile[9],  32'd6,   "x9  STATUS after illegal op = DONE|ERR");
        check_eq(dut.reg_file4.regfile[11], 32'd55,  "x11 add of two results");
        check_eq(dut.reg_file4.regfile[12], 32'd55,  "x12 SRAM store/load round trip");

        $display("\n=== coprocessor internal state ===");
        check_eq(dut.u_vec.u_vrf.vr[1][31:0],    32'd1,  "v1[0]");
        check_eq(dut.u_vec.u_vrf.vr[1][127:96],  32'd4,  "v1[3]");
        check_eq(dut.u_vec.u_vrf.vr[2][31:0],    32'd10, "v2[0]");
        check_eq(dut.u_vec.u_vrf.vr[2][127:96],  32'd40, "v2[3]");
        check_eq(dut.u_vec.u_vrf.vr[3][31:0],    32'd11, "v3[0]");
        check_eq(dut.u_vec.u_vrf.vr[3][63:32],   32'd22, "v3[1]");
        check_eq(dut.u_vec.u_vrf.vr[3][95:64],   32'd33, "v3[2]");
        check_eq(dut.u_vec.u_vrf.vr[3][127:96],  32'd44, "v3[3]");
        check_eq(dut.u_vec.result_r, 32'd110, "RESULT register");
        check_eq({29'd0, dut.u_vec.err, dut.u_vec.done, dut.u_vec.busy}, 32'b110, "STATUS = ERR|DONE|!BUSY");

        $display("\n=== address decode: no leakage between SRAM and coprocessor ===");
        // Uses only the data_mem PORTS (memwrite/A/WD), never its internal array,
        // so it works with any data_mem implementation.
        check_eq(sram_wr_cnt,  32'd1,  "exactly one write reached the data SRAM (the sw x11,0(x0))");
        check_eq(sram_last_a,  32'd0,  "that SRAM write went to address 0");
        check_eq(sram_last_d,  32'd55, "that SRAM write carried 55");
        check_eq(dut.u_vec.u_vrf.vr[0][31:0], 32'd0, "coprocessor v0[0] untouched by the SRAM store");
        check_eq(cp_wr_cnt, 32'd17, "coprocessor received all 17 of its stores (8 data + 9 command)");

        $display("\n=============================================");
        $display(" checks run : %0d", checks);
        $display(" errors     : %0d", errors);
        if (errors == 0) $display(" TEST PASSED");
        else             $display(" TEST FAILED");
        $display("=============================================\n");
        $finish;
    end

endmodule