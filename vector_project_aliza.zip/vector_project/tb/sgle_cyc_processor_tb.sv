`timescale 1ns/1ps
// =============================================================================
// Self-checking testbench for sgle_cyc_processor
//
// Program under test (ins_little_endian.hex):
//   0x00  addi x1,x0,10        x1 = 10
//   0x04  addi x2,x0,20        x2 = 20
//   0x08  add  x3,x1,x2        x3 = 30
//   0x0C  sub  x4,x2,x1        x4 = 10
//   0x10  sw   x3,0(x0)        mem[0] = 30
//   0x14  lw   x5,0(x0)        x5 = 30
//   0x18  beq  x3,x5,+8        taken  -> 0x20   (0x1C must be skipped)
//   0x1C  addi x6,x0,99        (skipped)
//   0x20  addi x6,x0,1         x6 = 1
//   0x24  jal  x0,+8           -> 0x2C          (0x28 must be skipped)
//   0x28  addi x7,x0,99        (skipped)
//   0x2C  addi x7,x0,7         x7 = 7
//   0x30  jal  x0,0            halt loop
//
// NOTE: x6 and x7 end up with the "right" value even if the branch/jump were
// broken (99 is overwritten later), so the PC-sequence check is what really
// proves the control flow. Do not remove it.
//
// Output guide:
//   [MON]  $monitor line  : state of the NEW cycle (after each clock edge)
//   [SB]   scoreboard line: result of the instruction that just COMPLETED at
//                           this clock edge (sampled just before the edge)
// =============================================================================
module sgle_cyc_processor_tb;

    localparam time CLK_PERIOD     = 10;
    localparam int  N_EXP          = 11;     // committed instructions incl. halt loop
    localparam int  TIMEOUT_CYCLES = 500;

    logic clk, rst;
    int   errors = 0;
    int   checks = 0;

    // ------------------------------------------------------------------ DUT
    sgle_cyc_processor dut (.clk(clk), .rst(rst));

    // ---------------------------------------------------------------- clock
    initial clk = 1'b0;
    always #(CLK_PERIOD/2) clk = ~clk;

    // ------------------------------------------------------ tiny disassembler
    // Written with $sformat into a packed vector (instead of a `string`) so that
    // $monitor / %s work in every simulator (Icarus crashes on string vars in $monitor).
    localparam int DW_TXT = 8*24;
    logic [DW_TXT-1:0] dis;

    task automatic decode(input logic [31:0] i, output logic [DW_TXT-1:0] s);
        logic [6:0] op;
        logic [2:0] f3;
        logic [4:0] rd, rs1, rs2;
        int         imm_i, imm_s, imm_b, imm_j;
        begin
            op  = i[6:0];   f3  = i[14:12];
            rd  = i[11:7];  rs1 = i[19:15];  rs2 = i[24:20];
            imm_i = $signed(i[31:20]);
            imm_s = $signed({i[31:25], i[11:7]});
            imm_b = $signed({i[31], i[7], i[30:25], i[11:8], 1'b0});
            imm_j = $signed({i[31], i[19:12], i[20], i[30:21], 1'b0});
            case (op)
                7'b0010011: if (f3 == 3'b000) $sformat(s, "addi x%0d,x%0d,%0d", rd, rs1, imm_i);
                            else              $sformat(s, "op-imm f3=%0d", f3);
                7'b0000011: $sformat(s, "lw   x%0d,%0d(x%0d)", rd, imm_i, rs1);
                7'b0100011: $sformat(s, "sw   x%0d,%0d(x%0d)", rs2, imm_s, rs1);
                7'b1100011: $sformat(s, "beq  x%0d,x%0d,%0d", rs1, rs2, imm_b);
                7'b1101111: $sformat(s, "jal  x%0d,%0d", rd, imm_j);
                7'b0110011: case (f3)
                                3'b000:  if (i[30]) $sformat(s, "sub  x%0d,x%0d,x%0d", rd, rs1, rs2);
                                         else       $sformat(s, "add  x%0d,x%0d,x%0d", rd, rs1, rs2);
                                3'b010:  $sformat(s, "slt  x%0d,x%0d,x%0d", rd, rs1, rs2);
                                3'b110:  $sformat(s, "or   x%0d,x%0d,x%0d", rd, rs1, rs2);
                                3'b111:  $sformat(s, "and  x%0d,x%0d,x%0d", rd, rs1, rs2);
                                default: $sformat(s, "r-type ?");
                            endcase
                default:    $sformat(s, "unknown");
            endcase
        end
    endtask

    always @* decode(dut.instruction, dis);

    // --------------------------------------------------------------- $monitor
    // Prints once per time-step in which any listed value changed.
    initial begin
        $monitor("[MON %0t] rst=%b pc=%08h ins=%08h %0s | srcA=%08h srcB=%08h alu=%08h zero=%b pc_src=%b | rw=%b mw=%b wb=%08h",
                 $time, rst, dut.pc, dut.instruction, dis,
                 dut.RD1, dut.srcb, dut.alu_result, dut.zero, dut.pc_src,
                 dut.regwrite, dut.memwrite, dut.W_Data);
    end

    // ------------------------------------------------------- expected commits
    // kind: 0 = no architectural write (branch / jal x0 / halt loop)
    //       1 = register write  (exp_a = rd,      exp_v = value)
    //       2 = store           (exp_a = address, exp_v = data)
    logic [31:0] exp_pc   [0:N_EXP-1];
    int          exp_kind [0:N_EXP-1];
    logic [31:0] exp_a    [0:N_EXP-1];
    logic [31:0] exp_v    [0:N_EXP-1];

    task automatic set_exp(input int k, input logic [31:0] pc, input int kind,
                           input logic [31:0] a, input logic [31:0] v);
        exp_pc[k] = pc;  exp_kind[k] = kind;  exp_a[k] = a;  exp_v[k] = v;
    endtask

    task automatic build_expected();
        set_exp( 0, 32'h00, 1, 1, 10);   // addi x1,x0,10
        set_exp( 1, 32'h04, 1, 2, 20);   // addi x2,x0,20
        set_exp( 2, 32'h08, 1, 3, 30);   // add  x3,x1,x2
        set_exp( 3, 32'h0C, 1, 4, 10);   // sub  x4,x2,x1
        set_exp( 4, 32'h10, 2, 0, 30);   // sw   x3,0(x0)
        set_exp( 5, 32'h14, 1, 5, 30);   // lw   x5,0(x0)
        set_exp( 6, 32'h18, 0, 0,  0);   // beq  (taken)
        set_exp( 7, 32'h20, 1, 6,  1);   // addi x6,x0,1      (0x1C skipped)
        set_exp( 8, 32'h24, 0, 0,  0);   // jal  x0,+8
        set_exp( 9, 32'h2C, 1, 7,  7);   // addi x7,x0,7      (0x28 skipped)
        set_exp(10, 32'h30, 0, 0,  0);   // jal  x0,0 (halt loop)
    endtask

    // -------------------------------------------------------- check helpers
    task automatic check(input bit cond, input string msg);
        checks++;
        if (cond) $display("[PASS] %s", msg);
        else begin
            errors++;
            $display("[FAIL %0t] %s", $time, msg);
        end
    endtask

    task automatic check_reg(input int r, input logic [31:0] expected);
        logic [31:0] got;
        got = dut.reg_file4.regfile[r];
        checks++;
        if (got === expected)
            $display("[PASS] x%-2d = 0x%08h (%0d)", r, got, got);
        else begin
            errors++;
            $display("[FAIL] x%-2d = 0x%08h, expected 0x%08h", r, got, expected);
        end
    endtask

    // ------------------------------------------------ per-instruction scoreboard
    int idx   = 0;      // which expected commit we are checking
    bit sb_en = 0;

    always @(posedge clk) begin
        if (sb_en && !rst) begin
            bit          ok;
            logic [31:0] pc_e, a_e, v_e;
            int          kind_e;
            ok     = 1;
            pc_e   = exp_pc[idx];
            kind_e = exp_kind[idx];
            a_e    = exp_a[idx];
            v_e    = exp_v[idx];

            if ($isunknown(dut.pc) || $isunknown(dut.instruction)) begin
                ok = 0;
                $display("[FAIL %0t] X/Z on PC or instruction (pc=%h ins=%h)", $time, dut.pc, dut.instruction);
            end
            else begin
                // 1) fetch address = expected control flow
                if (dut.pc !== pc_e) begin
                    ok = 0;
                    $display("[FAIL %0t] PC = 0x%08h, expected 0x%08h (control-flow error)",
                             $time, dut.pc, pc_e);
                end
                // 2) architectural effect of this instruction
                case (kind_e)
                    1: begin
                        if (!(dut.regwrite && dut.instruction[11:7] == a_e[4:0] &&
                              dut.W_Data === v_e && !dut.memwrite)) begin
                            ok = 0;
                            $display("[FAIL %0t] expected x%0d <= 0x%08h, got rw=%b rd=x%0d data=0x%08h mw=%b",
                                     $time, a_e[4:0], v_e, dut.regwrite,
                                     dut.instruction[11:7], dut.W_Data, dut.memwrite);
                        end
                    end
                    2: begin
                        if (!(dut.data_mem8.memwrite && dut.data_mem8.A === a_e && dut.data_mem8.WD === v_e && !dut.regwrite)) begin
                            ok = 0;
                            $display("[FAIL %0t] expected mem[0x%08h] <= 0x%08h, got mw=%b addr=0x%08h data=0x%08h rw=%b",
                                     $time, a_e, v_e, dut.data_mem8.memwrite, dut.data_mem8.A, dut.data_mem8.WD, dut.regwrite);
                        end
                    end
                    default: begin
                        // no memory write, and no write to any register except x0 (jal x0)
                        if (dut.memwrite || (dut.regwrite && dut.instruction[11:7] != 5'd0)) begin
                            ok = 0;
                            $display("[FAIL %0t] unexpected write: mw=%b rw=%b rd=x%0d",
                                     $time, dut.memwrite, dut.regwrite, dut.instruction[11:7]);
                        end
                    end
                endcase
            end

            checks++;
            if (!ok) errors++;

            $display("[SB  %0t] #%-2d pc=0x%08h %0s  %s", $time, idx, dut.pc, dis,
                     ok ? "OK" : "<<< MISMATCH");

            if (idx < N_EXP-1) idx++;      // stay on the halt-loop entry once reached
        end
    end

    // ------------------------------------------------------------- watchdog
    initial begin
        #(CLK_PERIOD * TIMEOUT_CYCLES);
        $display("[FAIL] TIMEOUT - program never reached the halt loop (idx=%0d)", idx);
        $display("TEST FAILED");
        $finish;
    end

    // ------------------------------------------------------------ main test
    initial begin
        $timeformat(-9, 0, " ns", 8);      // print all %0t times in ns
        $dumpfile("sgle_cyc_processor.vcd");
        $dumpvars(0, sgle_cyc_processor_tb);

        build_expected();
        sb_en = 0;
        rst   = 1;

        $display("\n=== TEST 1: power-on reset ===");
        repeat (3) @(posedge clk);
        #1 check(dut.pc === 32'h0, "PC must be 0 while reset is asserted");

        $display("\n=== TEST 2: run program (control-flow + write-back scoreboard) ===");
        @(negedge clk);            // release reset away from the active edge
        rst   = 0;
        sb_en = 1;

        wait (idx == N_EXP-1);     // scoreboard has reached the halt-loop entry
        repeat (5) @(posedge clk); // let the halt loop spin a few times
        @(negedge clk);            // switch the scoreboard off away from an active edge
        sb_en = 0;

        $display("\n=== TEST 3: final architectural state ===");
        check_reg(1, 10);
        check_reg(2, 20);
        check_reg(3, 30);
        check_reg(4, 10);
        check_reg(5, 30);          // proves sw -> data memory -> lw round trip
        check_reg(6,  1);
        check_reg(7,  7);
        check(dut.pc === 32'h30, "PC parked in the halt loop at 0x30");

        $display("\n=== TEST 4: asynchronous reset while running ===");
        @(negedge clk);
        rst = 1;
        #1 check(dut.pc === 32'h0, "PC cleared asynchronously (no clock edge needed)");
        @(negedge clk);
        rst = 0;
        @(posedge clk); #1
        check(dut.pc === 32'h4, "PC restarts and advances 0x00 -> 0x04 after reset release");
        @(posedge clk); #1
        check(dut.pc === 32'h8, "PC advances 0x04 -> 0x08");

        $display("\n=============================================");
        $display(" checks run : %0d", checks);
        $display(" errors     : %0d", errors);
        if (errors == 0) $display(" TEST PASSED");
        else             $display(" TEST FAILED");
        $display("=============================================\n");
        $finish;
    end

endmodule
