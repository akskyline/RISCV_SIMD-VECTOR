// =============================================================================
// riscv_soc_top - your single-cycle RV32I core + memory-mapped vector coprocessor
//
// Identical to sgle_cyc_processor except for the data-side bus:
//
//     alu_result (data address)
//        |-- 0x0000_0000 - 0x0000_07FF  -> data SRAM   (data_mem)
//        `-- 0x0000_0800 - 0x0000_0FFF  -> vec_coproc  (2 KB register window)
//
//     store : memwrite is gated so it reaches ONLY the selected target
//     load  : read data is muxed back into the write-back path (RD)
//
// The window sits at 0x800 because the core has no LUI yet: software can build
// the base address with  addi x10,x0,1024 ; add x10,x10,x10  and then use
// 12-bit offsets. Once LUI is added, move COPROC_BASE anywhere (e.g. 0x4000_0000).
// No change to the core's instruction set or control unit is needed.
// =============================================================================
module riscv_soc_top #(
    parameter logic [31:0] COPROC_BASE = 32'h0000_0800     // 2 KB aligned
)(
    input logic clk, rst
);

// intermediate 
logic        zero;
logic regwrite, alu_src, memwrite, branch, jump, pc_src;
logic [1:0] imm_src, result_src;
logic [2:0] ALUControl;
logic [31:0] RD;
logic [31:0] pc, pc_next, instruction, alu_result;
logic [31:0] W_Data;
logic [31:0] RD1,RD2; 
logic [31:0] imm,srcb;
logic [31:0] pcplus_4;

// data-bus split
logic        cp_sel;
logic [31:0] RD_dmem, RD_cp;


//pc_top(combine pc)
pc_top pc_counter1(
    .clk(clk),
    .rst(rst),
    .pc_src(pc_src),    
    .imm(imm),              
    .pc(pc),
    .pcplus_4(pcplus_4),
    .pc_next(pc_next)
);

//Instruction memory
ins_mem ins_mem2(
    .addr(pc),
    .instruction(instruction)
);

// control unit
control_unit cu3(
    .ins       (instruction),
    .zero      (zero),
    .regwrite  (regwrite),
    .alu_src   (alu_src),
    .memwrite  (memwrite),
    .result_src(result_src),
    .imm_src   (imm_src),
    .branch    (branch),
    .jump      (jump),
    .pc_src    (pc_src),
    .ALUControl(ALUControl)
);

//register file
register_file reg_file4(
    .clk(clk),
    .regwrite(regwrite),
    .instruction(instruction),
    .WD_reg(W_Data),
    .RD1(RD1),
    .RD2(RD2)
);

imm_data immdata5(
    .ins(instruction),
    .imm_src(imm_src),
    .imm(imm)
);

alu_mux alu_mux6(
    .RD2(RD2),
    .imm(imm),
    .alu_src(alu_src),
    .srcb(srcb)
);

alu alu7(
    .RD1(RD1),
    .srcb(srcb),
    .ALUControl(ALUControl),
    .alu_result(alu_result),
    .zero(zero)
);

// ------------------------------------------------------------------ data bus
assign cp_sel = (alu_result[31:11] == COPROC_BASE[31:11]);

data_mem data_mem8(
    .clk(clk),
    .memwrite(memwrite & ~cp_sel),          // SRAM write only when NOT addressing the coprocessor
    .A(alu_result),
    .WD(RD2),
    .RD(RD_dmem)
);

vec_coproc u_vec(
    .clk  (clk),
    .rst  (rst),
    .sel  (cp_sel),
    .we   (memwrite),                       // qualified by sel inside the coprocessor
    .addr (alu_result[10:0]),
    .wdata(RD2),
    .rdata(RD_cp)
);

assign RD = cp_sel ? RD_cp : RD_dmem;

memtoreg_mux_3to1 mux_ressult9(
    .alu_result(alu_result),
    .RD(RD),
    .result_src(result_src),
    .PCPlus4(pcplus_4),
    .WD(W_Data)
);

endmodule
