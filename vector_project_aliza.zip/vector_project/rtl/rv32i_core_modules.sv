// =============================================================================
// Your single-cycle RV32I core modules (as pasted), de-duplicated:
// main_decoder / alu_decoder_3bit / control_unit were pasted 3 times, which is a
// "module redefined" error - only one copy of each is kept. Logic is unchanged.
// =============================================================================

// MUX:  for ALU Side (RD2 or immediate)
module alu_mux(
    input  logic [31:0] RD2,    // register file output 
    input  logic [31:0] imm,    // immediate from imm_ext
    input  logic  alu_src,      // control: 0 -> RD2, 1 -> imm
    output logic [31:0] srcb    // ALU second operand 
);
    assign srcb = (alu_src) ? imm : RD2;
endmodule

// ALU
module alu(
    input  logic [31:0] RD1, srcb,
    input  logic [2:0]  ALUControl,
    output logic [31:0] alu_result,
    output logic        zero
);

    always_comb
        case (ALUControl)
            3'b000: alu_result = RD1 + srcb;            // ADD
            3'b001: alu_result = RD1 - srcb;            // SUB
            3'b010: alu_result = RD1 & srcb;            // AND
            3'b011: alu_result = RD1 | srcb;            // OR
            3'b101: alu_result = (RD1 < srcb) ? 32'd1 : 32'd0; // SLT
            default: alu_result = 32'hxxxxxxxx;
        endcase 

    assign zero = (RD1 == srcb) ? 1'b1 : 1'b0;  
endmodule

//Main Decoder
module main_decoder (
    input logic [31:0] ins, 
    input logic  zero,     
    output logic [1:0] imm_src, alu_op, result_src,    
    output logic regwrite, alu_src, memwrite, branch, jump, pc_src); 

logic [6:0] opcode;
assign opcode = ins[6:0];
logic [10:0] controls;

always_comb
case (opcode)
7'b0000011: controls = 11'b1_00_1_0_01_0_00_0;  //LW
7'b0100011: controls = 11'b0_01_1_1_xx_0_00_0;  //SW
7'b0110011: controls = 11'b1_xx_0_0_00_0_10_0;  //R-type
7'b1100011: controls = 11'b0_10_0_0_xx_1_01_0;  //Beq
7'b0010011: controls = 11'b1_00_1_0_00_0_10_0;  //addi
7'b1101111: controls = 11'b1_11_x_0_10_0_xx_1;  //Jal
default:    controls = 11'bx_xx_x_x_xx_x_xx_x;  
endcase

assign {regwrite, imm_src, alu_src, memwrite, result_src, branch, alu_op, jump} = controls;

assign pc_src = (zero && branch)|jump;

endmodule

//ALU Decorder
module alu_decoder_3bit (
    input  logic [1:0] alu_op,      // from main control unit
    input  logic [31:0] ins,  
    output logic [2:0] ALUControl  // 3-bit control signal to ALU
);
logic [6:0] opcode;
logic [2:0] funct3;
logic [6:0] funct7;
assign opcode = ins[6:0];
assign funct3 = ins[14:12];
assign funct7 = ins[31:25];
    always_comb 
        case (alu_op)
            2'b00: ALUControl = 3'b000; // Load/store -> ADD
            2'b01: ALUControl = 3'b001; // Branch -> SUB
            2'b10: begin                // R-type instructions
                case (funct3)
                    3'b000: ALUControl = (opcode[5] & funct7[5])?3'b001: 3'b000; // sub , add
                    3'b010: ALUControl = 3'b101; // slt
                    3'b110: ALUControl = 3'b011; // or
                    3'b111: ALUControl = 3'b010; // and
                    default:ALUControl = 3'bxxx; // Default 
                endcase
                end
            default: ALUControl = 3'bxxx;
        endcase
endmodule

//Control Unit using above two sub prts(alu and main decoder)
module control_unit (
    input  logic [31:0] ins,     // bits [31:25]
    input  logic       zero,
    output logic [2:0] ALUControl, // from ALU decoder
    output logic [1:0] imm_src, result_src,
    output logic       regwrite,
    output logic       alu_src,
    output logic       memwrite,
    output logic       branch,
    output logic       jump,
    output logic       pc_src
);

    // Internal connection
    logic [1:0] alu_op;

    // Instantiate Main Decoder
    main_decoder MAIN_DEC (
        .ins      (ins),
        .zero      (zero),
        .regwrite (regwrite),
        .alu_src   (alu_src),
        .memwrite  (memwrite),
        .result_src(result_src),
        .imm_src   (imm_src),
        .branch    (branch),
        .jump      (jump),
        .alu_op    (alu_op),
        .pc_src    (pc_src)
    );

    // Instantiate ALU Decoder
    alu_decoder_3bit ALU_DEC (
        .alu_op     (alu_op),
        .ins        (ins),
        .ALUControl (ALUControl)
    );

endmodule

//instruction memory module
module ins_mem(input logic [31:0] addr,
output logic [31:0] instruction);

logic [7:0] ins_mem [0:4095];


initial begin
$readmemh("./ins_little_endian.hex",ins_mem); //("file", array_name, start_addr, end_addr)
end
assign instruction = {ins_mem[addr+3], ins_mem[addr+2], ins_mem[addr+1], ins_mem[addr]}; 
endmodule 

// program counter module
module program_counter(
    input  logic        clk,rst,
    input  logic [31:0] pc_next,
    output logic [31:0] pc
);
    always_ff @(posedge clk or posedge rst) begin
        if (rst)
            pc <= 32'h00000000;    // initial address
        else
            pc <= pc_next;
    end
endmodule

//Alu_pc, pc + 4
module alu_pc(
    input  logic [31:0] pc,
    output logic [31:0] pcplus_4
);
    assign pcplus_4 = pc + 32'd4;
endmodule

// ALU for branch 
module alu_pc_target(
    input  logic [31:0] pc,       
    input  logic [31:0] imm,   
    output logic [31:0] pc_target 
);
    assign pc_target = pc + imm;
endmodule

//pc mux2_1
module pc_src_mux(
    input  logic [31:0] pcplus_4, pc_target,
    input  logic        pc_src,
    output logic [31:0] pc_next
);
    assign pc_next = (pc_src) ? pc_target : pcplus_4;
endmodule

//pc_top(combine pc)
module pc_top(
    input  logic        clk, rst, pc_src,    
    input  logic [31:0] imm,              
    output logic [31:0] pc,
    output logic [31:0] pcplus_4,
    output logic [31:0] pc_next
);

    // Internal signal

    logic [31:0] pc_target;

    // 1. Program Counter Register
    program_counter pc_current (
        .clk(clk),
        .rst(rst),
        .pc_next(pc_next),
        .pc(pc)
    );

    // 2. ALU for PC + 4
    alu_pc pc_adder_4 (
        .pc(pc),
        .pcplus_4(pcplus_4)
    );

    // 3. ALU for PC + Immediate (Branch Target)
    alu_pc_target pc_target_alu (
        .pc(pc),
        .imm(imm),
        .pc_target(pc_target)
    );

    // 4. MUX for selecting next PC
    pc_src_mux pc_mux (
        .pcplus_4(pcplus_4),      
        .pc_target(pc_target),  
        .pc_src(pc_src),
        .pc_next(pc_next)
    );

endmodule

//Register file(32x32)
module register_file(
    input  logic  clk, regwrite, 
    input  logic [31:0] instruction,
    input  logic [31:0] WD_reg,
    output logic [31:0] RD1, RD2
);
    logic [4:0] A1, A2, A3;
    assign A1 = instruction[19:15]; //A1, A2 = source register, A3 = destination register
    assign A2 = instruction[24:20];
    assign A3 = instruction[11:7];

    logic [31:0] regfile [31:0];   // 32 registers, 32 bits each

  // WRITE 
    always_ff @(posedge clk) 
        begin
        if (regwrite)
            regfile[A3] <= WD_reg;   
         end
    
    // READ 
    assign RD1 = (A1 != 5'd0)? regfile[A1] : 0;
    assign RD2 = (A2 != 5'd0)? regfile[A2] : 0;

  endmodule
module sgle_cyc_processor(input logic clk, rst);

// intermediate 
logic        zero;
logic regwrite, alu_src, memwrite, branch, jump, pc_src;
logic [1:0] imm_src, result_src;
logic [2:0] ALUControl;
logic [31:0] RD;
logic [31:0] pc, pc_next, instruction, alu_result;
logic [31:0] W_Data;
logic [31:0] RD1,RD2; 
logic [31:0] imm,srcb;
logic [31:0] pcplus_4;

 

//pc_top(combine pc)
pc_top pc_counter1(
    .clk(clk),
    .rst(rst),
    .pc_src(pc_src),    
    .imm(imm),              
    .pc(pc),
    .pcplus_4(pcplus_4),
    .pc_next(pc_next)
);


//Instruction memory
ins_mem ins_mem2(
    .addr(pc),
    .instruction(instruction)
);


// control unit
control_unit cu3(
    .ins       (instruction),
    .zero      (zero),
    .regwrite  (regwrite),
    .alu_src   (alu_src),
    .memwrite  (memwrite),
    .result_src(result_src),
    .imm_src   (imm_src),
    .branch    (branch),
    .jump      (jump),
    .pc_src    (pc_src),
    .ALUControl(ALUControl)
);


//register file
register_file reg_file4(
    .clk(clk),
    .regwrite(regwrite),
    .instruction(instruction),
    .WD_reg(W_Data),
    .RD1(RD1),
    .RD2(RD2)
);

imm_data immdata5(
    .ins(instruction),
    .imm_src(imm_src),
    .imm(imm)
);

alu_mux alu_mux6(
    .RD2(RD2),
    .imm(imm),
    .alu_src(alu_src),
    .srcb(srcb)
);

alu alu7(
    .RD1(RD1),
    .srcb(srcb),
    .ALUControl(ALUControl),
    .alu_result(alu_result),
    .zero(zero)
);


data_mem data_mem8(
    .clk(clk),
    .memwrite(memwrite),
    .A(alu_result),
    .WD(RD2),
    .RD(RD)
);


memtoreg_mux_3to1 mux_ressult9(
    .alu_result(alu_result),
    .RD(RD),
    .result_src(result_src),
    .PCPlus4(pcplus_4),
    .WD(W_Data)
    
);
endmodule
